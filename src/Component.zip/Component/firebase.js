import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCvtpX7mAUZTnOsTZdpHe_nQSvYXMLVLqo",
  authDomain: "proj3-77.firebaseapp.com",
  projectId: "proj3-77",
  storageBucket: "proj3-77.appspot.com",
  messagingSenderId: "1034512819155",
  appId: "1:1034512819155:web:ea5465f4bf1eb27e5a0526",
  measurementId: "G-D88YZ0FK90"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
